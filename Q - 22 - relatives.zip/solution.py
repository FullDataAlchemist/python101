all_users = {}
all_albums = {}


def add_user(username: str, age: int, city: str, albums: list, all_users: dict, all_albums: dict):
    pass


def add_album(name: str, artist_name: str, genre: str, tracks: int, all_users: dict, all_albums: dict):
    pass


def query_user_artist(username: str, artist_name: str, all_users: dict, all_albums: dict) -> int:
    pass


def query_user_genre(username: str, genre: str, all_users: dict, all_albums: dict) -> int:
    pass


def query_age_artist(age: int, artist_name: str, all_users: dict, all_albums: dict) -> int:
    pass


def query_age_genre(age: int, genre: str, all_users: dict, all_albums: dict) -> int:
    pass


def query_city_artist(city: str, artist_name: str, all_users: dict, all_albums: dict) -> int:
    pass


def query_city_genre(city: str, genre: str, all_users: dict, all_albums: dict) -> int:
    pass

# DO NOT USE YOUR OWN TESTS HERE, USE SAMPLE TEST INSTEAD
