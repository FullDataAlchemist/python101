def check_registration_rules(**kwargs):
    pass
